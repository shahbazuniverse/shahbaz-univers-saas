﻿export type UserRole = 'superadmin' | 'admin' | 'moderator' | 'user';
export interface UserProfile {
  uid: string;
  email: string;
  role: UserRole;
}
