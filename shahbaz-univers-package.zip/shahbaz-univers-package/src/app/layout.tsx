﻿import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "SHAHBAZ UNIVERS",
  description: "Commercial SaaS Platform",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
