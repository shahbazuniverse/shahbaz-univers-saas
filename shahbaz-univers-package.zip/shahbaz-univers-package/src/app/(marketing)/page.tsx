﻿export default function HomePage() {
  return (
    <div style={{ textAlign: "center", padding: "50px" }}>
      <h1>Welcome to SHAHBAZ UNIVERS SaaS Starter Kit</h1>
      <p>Production Ready Architecture for Next.js & Firebase</p>
    </div>
  );
}
