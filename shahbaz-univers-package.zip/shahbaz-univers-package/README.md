﻿# SHAHBAZ UNIVERS - SaaS Boilerplate (Commercial Edition)
Complete Enterprise Ready Starter Kit with Next.js 14, Firebase Auth & Firestore.

## Quick Start
1. Run `npm install`
2. Add `.env.local`
3. Run `npm run dev`
